package com.example.ism_2026;

public class FXRate {

    private String date;
    private String euro;
    private String dolar;
    private String pound;
    private String gold;

    public String getDate() {
        return date;
    }

    public String getEuro() {
        return euro;
    }

    public String getDolar() {
        return dolar;
    }

    public String getPound() {
        return pound;
    }

    public String getGold() {
        return gold;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setEuro(String euro) {
        this.euro = euro;
    }

    public void setDolar(String dolar) {
        this.dolar = dolar;
    }

    public void setPound(String pound) {
        this.pound = pound;
    }

    public void setGold(String gold) {
        this.gold = gold;
    }

    @Override
    public String toString() {
        return "FXRate{" +
                "date='" + date + '\'' +
                ", euro='" + euro + '\'' +
                ", dolar='" + dolar + '\'' +
                ", pound='" + pound + '\'' +
                ", gold='" + gold + '\'' +
                '}';
    }
}
